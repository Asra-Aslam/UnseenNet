import argparse
import sys
import os
from sys  import argv 
import shutil
from shutil import copyfile

from Find_Similar_Classes.find_top_semantically_similar_class_index import find_top_semantically_similar_class_index
from Utils.change_classname import change_classname
from Utils.Generate_Training_Annotations_Unseen_Classes import Generate_Training_Annotations_Unseen_Classes_and_Separate_Adaptation_images
from Utils.calculate_epochs import calculate_epochs
from Utils.calculate_epochs import calculate_transfer_epochs
from YOLOv3_MobileNetv3.Train_Unseen_Classes import User_Input_and_Start_Training
from YOLOv3_MobileNetv3.Train_Unseen_Classes import start_training
from YOLOv3_MobileNetv3.Detect_Unseen_Classes import User_Input_and_Start_Detecting
from YOLOv3_MobileNetv3.Detect_Unseen_Classes import start_detecting
from YOLOv3_MobileNetv3.find_prediction_weights import start_adapting
from Utils.save_classes_detection_weights import save_classes_detection_weights
from Utils.compute_median import compute_median
from Utils.compute_visual_similarities import compute_visual_similarities
from Utils.Compute_Bias_using_Semantic_and_Visual_Similarity import Compute_Bias_using_Semantic_and_Visual_Similarity
from Download_Images.download import user_input
from Download_Images.download import download	#-----importing this to dowload images from Bing-----





#-------------initialization starts---------------------------------------------------------------------------------------------------
seen_file="seen.txt"
parser = argparse.ArgumentParser()
user_input(parser)
User_Input_and_Start_Training(parser)
User_Input_and_Start_Detecting(parser)
path=os.getcwd()
args = parser.parse_args()
#-------------initialization ends-----------------------------------------------------------------------------------------------------





#-----Code for Downloading images starts----------------------------------------------------------------------------------------------
temp_images_path=path+"/Training_Data/images/temp"
if os.path.isdir(temp_images_path):
	shutil.rmtree(temp_images_path)
os.mkdir(temp_images_path)

saving_path=path+"/Training_Data/images/"+args.unseen_classname	#+"/"
if os.path.isdir(saving_path):
	shutil.rmtree(saving_path)
os.mkdir(saving_path)

download(parser)	#-----calling this to call our Bing Imgaes Downloader previously it was "bing_scraper(*argv)"--------
#-----Code for Downloading images ends------------------------------------------------------------------------------------------------





#-----Code for finding top Semantic Similar Class for Finetuning Starts---------------------------------------------------------------
#print(inputs)
#similarity('coin')


#for arguments in inputs:
	
if args.unseen_classname:
	top_semantically_similar_index=find_top_semantically_similar_class_index(args.unseen_classname, args.top)
	unseen_classname=args.unseen_classname

print("Your similarity class index is "+str(top_semantically_similar_index))
#-----Code for finding top Semantic Similar Class for Finetuning Ends-----------------------------------------------------------------





#-----Code for Changing Classname Starts----------------------------------------------------------------------------------------------
unseen_class_file=unseen_classname+".txt"
copyfile(seen_file,unseen_class_file)
change_classname(unseen_classname, top_semantically_similar_index, unseen_class_file)
copyfile(unseen_class_file,"YOLOv3_MobileNetv3/configs/"+unseen_class_file)
os.remove(unseen_class_file)
#-----Code for Changing Classname Ends------------------------------------------------------------------------------------------------





#-----Code for Generating Annotations Starts------------------------------------------------------------------------------------------
Generate_Training_Annotations_Unseen_Classes_and_Separate_Adaptation_images(top_semantically_similar_index, unseen_classname)
#-----Code for Generating Annotations Ends--------------------------------------------------------------------------------------------





#-----Code for Computation of Number of Epochs Starts---------------------------------------------------------------------------------
print("Your Response-Time presently is "+str(args.response_time)+" min")
Response_Time=args.response_time
Batch_Size=16
One_Iteration_Time=0.465

images_folder_path=path+"/Training_Data/images/"+unseen_classname+"/"
files=os.listdir(images_folder_path)
Num_of_Training_Images=len(files)
print("Number of available Training Images: "+str(Num_of_Training_Images))

epochs=calculate_epochs(Response_Time, Batch_Size, Num_of_Training_Images, One_Iteration_Time)
transfer_epochs=calculate_transfer_epochs(int(epochs))
print("Number of Epochs: "+str(epochs)+" and Number of Transfer Epochs: "+str(transfer_epochs))
#-----Code for Computation of Number of Epochs Ends----------------------------------------------------------------------------------





#------Code for Training Starts------------------------------------------------------------------------------------------------------
learning_rate=0.0001
start_training(parser, epochs, transfer_epochs, learning_rate, unseen_classname)
copyfile("YOLOv3_MobileNetv3/logs/000/trained_final.h5","YOLOv3_MobileNetv3/weights/"+unseen_classname+".h5")
print("\n\n\n\nCongratulations!!!!!Your model is trained for "+str(epochs)+" epochs according to your "+str(Response_Time)+" min training time.")
print("Now UnseenNet is Adapting for Unseen Class "+unseen_classname+"....this may take a moment...")
#------Code for Training Ends--------------------------------------------------------------------------------------------------------





#------Code for Adaptationn Starts------------------------------------------------------------------------------------------------------------------------------------
#----1. Create detecions for Adaptation------------------
adapt_detections_path=path+"/Training_Data/detections_for_adaptation/"+unseen_classname
if os.path.isdir(adapt_detections_path):
	shutil.rmtree(adapt_detections_path)

os.mkdir(adapt_detections_path)
	
adapt_test_images_path=path+"/Training_Data/images_for_adaptation/"+unseen_classname	#-------created this directory in gerating annotations file--------
weights_path="YOLOv3_MobileNetv3/weights/"+unseen_classname+".h5"
start_adapting(parser, weights_path, unseen_classname, adapt_test_images_path, adapt_detections_path)


#----2. Create detection weights for Unseen Classes------
adapt_detections_path=adapt_detections_path+"/"
distance_calculation_path=path+"/Utils/distance/"+unseen_classname+".csv"
if os.path.isfile(distance_calculation_path):
		os.remove(distance_calculation_path)	#-----first remove existing file if exists---------------

save_classes_detection_weights(adapt_detections_path, distance_calculation_path)	#-----this will give Utils/distance/unseenclassname.csv file------
compute_median(unseen_classname, distance_calculation_path)	#----this will give Utils/unseen_detection_weights.csv file----

source_file_path=path+"/Utils/unseen_detection_weights.csv"
destination_file_path=path+"/Utils/weak_detection_weights.csv"	#--remember to save weak_detection_weights.csv (provided by UnseenNet) in Utils folder--
compute_visual_similarities(source_file_path, destination_file_path)	#----this will give Utils/visual_similarities.csv file----

#----3. Find a bias to add-------------------------------
alpha=0.6
K=10
bias=Compute_Bias_using_Semantic_and_Visual_Similarity(unseen_classname, seen_file, alpha, K)
print("Bias to be added is: "+str(bias))

print("\n\n\n\nCongratulations!!!!!Your model is trained and Adapted after "+str(epochs)+" epochs according to your "+str(Response_Time)+" min training time.")
print("You can start Testing by providing your image path (like Testing_Data/example.jpg)")
input("Press ENTER to Start Detecting:")
#------Code for Adaptationn Ends--------------------------------------------------------------------------------------------------------------------------------------





#------Code for Testing Starts----------------------------------------------------------------------------------------------------------------------------------------
weights_path="YOLOv3_MobileNetv3/weights/"+unseen_classname+".h5"
start_detecting(parser, weights_path, unseen_classname, bias)
#----Ask if someone to test---
#------Code for Testing Ends------------------------------------------------------------------------------------------------------------------------------------------
