from nltk.corpus import wordnet

def find_top_semantically_similar_class_index(class_name_unseen, top):
	#class_name_unseen='coin'
	#top=10
	print("Unseen Class: " +class_name_unseen)

	seen_count=0
	seen_list=[]
	file_seen = open('seen.txt', 'r') 
	while True:
		line_seen = file_seen.readline()
		if not line_seen:
			break
		class_name_seen=line_seen.strip()
		#--find---similarity
		first = wordnet.synset(class_name_unseen+'.n.01')
		second = wordnet.synset(class_name_seen+'.n.01')
		similarity=first.path_similarity(second)
		#print(similarity)
		#print("Seen Class: " +class_name_seen +", " +str(similarity))
		seen_list.append([class_name_seen, similarity])
		#print("Seen Class: " +str(seen_list[seen_count][0]) +", " +str(seen_list[seen_count][1]))
		seen_count=seen_count+1
	file_seen.close()

	#-----find top similar seen classes------
	final_top_list=[]
	#print("Seen Count: " +str(seen_count) )
	for i in range(0,top):
		max_val=0
		max_index=0

		for j in range(0,seen_count):
			#print("Checking Seen Class: " +str(seen_list[j][0]))
			if seen_list[j][1]>max_val:
				max_val=seen_list[j][1]
				max_index=j
		final_top_list.append([seen_list[max_index][0], seen_list[max_index][1]])
		seen_list[max_index][1]=-1
		#seen_list[max_index].remove(seen_list[max_index][1])
	#print('Top List is:')
	#print(final_top_list)
	#return final_top_list


	file_seen = open('seen.txt', 'r') 
	i=0
	while True:
		line_seen = file_seen.readline()
		if not line_seen:
			break
		class_name_seen=line_seen.strip()
		top_similar_class=final_top_list[0][0]
		top_similar_class=top_similar_class.strip()

		if class_name_seen==top_similar_class:
			index=i
			break
		i=i+1
	file_seen.close()
	#print(str(index)+","+class_name_unseen)
	#print(index)	#----------this prints the index of top similar class-------------
	return index

