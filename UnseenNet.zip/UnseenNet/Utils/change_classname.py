from nltk.corpus import wordnet

def change_classname(class_name_unseen, class_name_index, unseen_class_filename):
	class_count=0
	class_list=[]
	file_unseen = open(unseen_class_filename, 'r') 
	new_file_content=""
	while True:
		line_class_name = file_unseen.readline()
		if not line_class_name:
			break
		class_name_to_be_replaced=line_class_name.strip()


		if str(class_count) == str(class_name_index):
			new_line=class_name_unseen.strip()
		else:
			new_line=class_name_to_be_replaced
		
		new_file_content+=new_line+"\n"

		class_count=class_count+1
	file_unseen.close()

	writing_file= open(unseen_class_filename, 'w')
	writing_file.write(new_file_content)
	writing_file.close()
