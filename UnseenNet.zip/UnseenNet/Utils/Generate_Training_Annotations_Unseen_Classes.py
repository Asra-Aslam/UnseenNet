from PIL import Image
import os
import sys
import shutil

def Generate_Training_Annotations_Unseen_Classes_and_Separate_Adaptation_images(class_index, unseen_classname):
	#--------initialization starts-----------
	x_min=5
	y_min=5
	#--------initialization ends-------------
			
	#print("Current path is: "+os.getcwd())
	path=os.getcwd()


	#class_index=sys.argv[1]
	#unseen_classname=sys.argv[2]#(sys.argv[2].strip()).lower()

	class_path=path+"/Training_Data/images/"+unseen_classname+"/"
	#print(class_path)

	des_annotation_path=path+"/Training_Data/annotations/"+unseen_classname+".txt"
	if os.path.isfile(des_annotation_path):
		os.remove(des_annotation_path)	#-----first remove existing file if exists---------------
	des_file_annotation=open(des_annotation_path, "a")	
	
	adapt_test_images_path=path+"/Training_Data/images_for_adaptation/"+unseen_classname+"/"
	if os.path.isdir(adapt_test_images_path):
		shutil.rmtree(adapt_test_images_path)
	os.mkdir(adapt_test_images_path)	

	#------------------count number of images to seperate training and testing for adapt images----------------------
	count=0
	for root, dirs, files in os.walk(class_path):
		for filename in files:
			#print(filename)			
			if filename.find("jpg")>-1 or filename.find("jpeg")>-1 or filename.find("png")>-1:
				image_path=class_path+""+filename
				try:
					image=Image.open(image_path)
					count=count+1
				except: 
					os.remove(image_path)
	adapt_test_count=int(count/10)
	train_count=count-adapt_test_count
	#----------------------------------------------------------------------------------------------------------------

	count=0
	for root, dirs, files in os.walk(class_path):
		for filename in files:
			#print(filename)			
			if filename.find("jpg")>-1 or filename.find("jpeg")>-1 or filename.find("png")>-1:
				image_path=class_path+""+filename
				#---checking height and width of image----
				if count<train_count:
					try:
						image=Image.open(image_path)
						width, height = image.size
						#print(width, height)
						#---checking ends----------------------
						x_max=width-5
						y_max=height-5
						box=""+str(x_min)+","+str(y_min)+","+str(x_max)+","+str(y_max)+","+str(class_index)
						line_to_write=""+image_path
						line_to_write=line_to_write+" "+box+"\n"
						#print(line_to_write)
						des_file_annotation.write(line_to_write)
					except: 
						os.remove(image_path)
				else:
					try:
						image=Image.open(image_path)
						dest_path=adapt_test_images_path+""+filename
						shutil.move(image_path, dest_path)
						
					except: 
						os.remove(image_path)
				count=count+1
	des_file_annotation.close
