import os
import csv
import sys
import statistics

def compute_median(unseen_classname, distance_calculation_path):
		
	classname=unseen_classname.strip()
	#print(classname)
	source_file_path=""+distance_calculation_path

	source_filesize=os.path.getsize(source_file_path)
	if source_filesize==0:
		print(classname+",0.00")
	else:
		all_values=[]
		with open(source_file_path) as source_csv_file:
			source_csv_reader=csv.reader(source_csv_file,delimiter=',')
			i=0
			for source_row in source_csv_reader:
				#print("Source: "+source_row[0]+" and "+source_row[1])
				source_value=float(source_row[1])
				all_values.append(source_value)
				i+=1
		median_for_class=statistics.median(all_values)
		#print("Median for class: "+classname+"is "+str(median_for_class))
		print(classname+","+str(median_for_class))

		#-------write to a file--------------
		path=os.getcwd()
		writing_file_path=path+"/Utils/unseen_detection_weights.csv"

		if os.path.isfile(writing_file_path):
			os.remove(writing_file_path)	#-----first remove existing file if exists---------------
		writing_file_path=open(writing_file_path, "a")

		line_to_write=""+classname+","+str(median_for_class)+"\n"
		#print(line_to_write)

		writing_file_path.write(line_to_write)
		writing_file_path.close
		#------------------------------------
