import sys

def calculate_epochs(Time, Batch_Size, Num_Images, One_Iteration_Time):
	#print(One_Iteration_Time)
	time_in_one_iteration=(float(Num_Images)/float(Batch_Size))*(float(One_Iteration_Time))
	epochs=float(Time*60)/float(time_in_one_iteration)

	#print(int(epochs))
	return int(epochs)


def calculate_transfer_epochs(epochs):
	#epochs=sys.argv[1]
	if int(epochs) > 20:
		transfer_epochs =20
	else:
		transfer_epochs = epochs

	#print(int(transfer_epochs))
	return int(transfer_epochs)
