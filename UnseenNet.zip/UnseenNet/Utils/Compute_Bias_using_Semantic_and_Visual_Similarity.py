from nltk.corpus import wordnet
import csv
import sys
import os

def Compute_Bias_using_Semantic_and_Visual_Similarity(class_name_unseen, seen_file_name, alpha, top):
	#top=10

	seen_count=0
	seen_list=[]
	file_seen = open(seen_file_name, 'r') 
	#file_seen = open('seen.txt', 'r') 
	while True:
		line_seen = file_seen.readline()
		if not line_seen:
			break
		class_name_seen=line_seen.strip()
		#--find---similarity
		first = wordnet.synset(class_name_unseen+'.n.01')
		second = wordnet.synset(class_name_seen+'.n.01')
		semantic_similarity=first.path_similarity(second)
		#print(similarity)
		#print("Seen Class: " +class_name_seen +", " +str(similarity))


		#--retrieving visual similarity starts--------
		path=os.getcwd()
		file_to_open=path+"/Utils/visual_similarities.csv"
		with open(file_to_open) as csv_file:
			csv_reader = csv.reader(csv_file, delimiter=',')
			for row in csv_reader:
				if (row[0].strip()).lower() == class_name_unseen.lower():			
					if (row[1].strip()).lower() == class_name_seen.lower():
						visual_similarity=float(row[2].strip())
						break
		csv_file.close
		#visual_similarity=0.7
		#--retrieving visual similarity ends----------

		similarity= (alpha * visual_similarity) + ((1-alpha)*semantic_similarity)

		seen_list.append([class_name_seen, similarity])
		#print("Seen Class: " +str(seen_list[seen_count][0]) +", " +str(seen_list[seen_count][1]))
		seen_count=seen_count+1
	file_seen.close()

	#-----find top similar seen classes------
	final_top_list=[]
	#print("Seen Count: " +str(seen_count) )
	for i in range(0,top):
		max_val=0
		max_index=0

		for j in range(0,seen_count):
			#print("Checking Seen Class: " +str(seen_list[j][0]))
			if seen_list[j][1]>max_val:
				max_val=seen_list[j][1]
				max_index=j
		final_top_list.append([seen_list[max_index][0], seen_list[max_index][1]])
		seen_list[max_index][1]=-1
		#seen_list[max_index].remove(seen_list[max_index][1])

	#print('Top List is:')
	#print(final_top_list)	#----this prints the top list of seen class which is similar to unseen class.

	#------------------computing bias starts-----------------
	path=os.getcwd()
	file_bias_to_open=path+"/Utils/bias.csv"
	total_bias=0
	total_sim=0
	for i in range(0,top):
		class_name_seen=final_top_list[i][0].strip()
		similarity_value=float(final_top_list[i][1])
		#----retrieving bias starts--------
		with open(file_bias_to_open) as csv_file:
			csv_reader = csv.reader(csv_file, delimiter=',')
			for row in csv_reader:
				if (row[0].strip()).lower() == class_name_seen.lower():	
					bias_value=float(row[1].strip())
					break
		csv_file.close
		#print("Bias value for "+class_name_seen+" is "+str(bias_value)+" and similarity is "+str(similarity_value)+", Final Sim "+str(similarity_value*bias_value))
		#----retrieving bias ends----------
		total_bias=total_bias+(similarity_value*bias_value)
		total_sim=total_sim+similarity_value

	#total_bias=total_bias/top
	#total_bias=total_bias/total_sim
	#------------------computing bias ends-------------------
	#print("Total Bias is "+str(total_bias))	#----this prints the total bias to be added to unseen class.
	#print(total_bias)
	return total_bias
