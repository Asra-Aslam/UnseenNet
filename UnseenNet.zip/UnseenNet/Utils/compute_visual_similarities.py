import os
import csv
import sys

def compute_visual_similarities(source_file_path, destination_file_path):
	#----------source is unseen class detections  path---------
	#---------destination is the weak classes detcetions path----------

	source_filesize=os.path.getsize(source_file_path)
	destination_filesize=os.path.getsize(destination_file_path)
	#print(source_file_path)
	if source_filesize==0:
		print("Source "+filename+" is Empty!!!")
	elif destination_filesize==0:
		print("Destination "+filename+" is Empty!!!")
	else:	
		#-------write to a file--------------
		path=os.getcwd()
		writing_file_path=path+"/Utils/visual_similarities.csv"

		if os.path.isfile(writing_file_path):
			os.remove(writing_file_path)	#-----first remove existing file if exists---------------
		writing_file_path=open(writing_file_path, "a")
		#------------------------------------


		#-------------reading source file starts------------------------------
		with open(source_file_path) as source_csv_file:
			source_csv_reader=csv.reader(source_csv_file,delimiter=',')
			i=0
			for source_row in source_csv_reader:
				#print("Source: "+source_row[0]+" and "+source_row[1])
				#-------------reading destination file starts------------------------------
				with open(destination_file_path) as destination_csv_file:
					destination_csv_reader=csv.reader(destination_csv_file,delimiter=',')
					for destination_row in destination_csv_reader:
						#print("Destination: "+destination_row[0]+" and "+destination_row[1])
						source_value=float(source_row[1])
						destination_value=float(destination_row[1])
						if source_value > destination_value:
							value_to_write=1-(source_value - destination_value)
						else:
							value_to_write=1-(destination_value - source_value)
						#print(source_row[0]+","+destination_row[0]+","+str(value_to_write))
						line_to_write=source_row[0]+","+destination_row[0]+","+str(value_to_write)+"\n"
						#print(line_to_write)
						writing_file_path.write(line_to_write)
				#-------------reading destination file ends--------------------------------
				i+=1
			#print("Processed lines: "+str(i))
		#-------------reading source file ends---------------------------------

		writing_file_path.close
