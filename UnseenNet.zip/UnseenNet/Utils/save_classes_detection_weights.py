import os
import csv
import sys


def save_classes_detection_weights(source_path, distance_file_path):
	
	#print(source_path)
	#print(destination_path)
	#print(class_path)
	#print("anonymous i am here")

	distance_file=open(distance_file_path, "w+")

	for root, dirs, files in os.walk(source_path):
		for filename in files:
			source_file_path=source_path+""+filename	
			source_filesize=os.path.getsize(source_file_path)
			#print(source_file_path)
			if source_filesize==0:
				print("Source "+filename+" is Empty!!! and thats Okay :-) I am using other images!!!")
			else:		
				image_name=filename.split(".")[0]
				image_name=image_name+".jpg"
				#-------------reading source file starts------------------------------
				with open(source_file_path) as source_csv_file:
					source_csv_reader=csv.reader(source_csv_file,delimiter=',')
					i=0
					for source_row in source_csv_reader:
						#print("Source: "+source_row[0]+" and "+source_row[1])
						source_value=float(source_row[1])
						value_to_write=source_value
						#print("----writing just source: "+str(source_value))
						line_to_write=image_name+","+str(value_to_write)+"\n"
						distance_file.write(line_to_write)
						i+=1
					#print("Processed lines: "+str(i))
				#-------------reading source file ends---------------------------------
	distance_file.close()
